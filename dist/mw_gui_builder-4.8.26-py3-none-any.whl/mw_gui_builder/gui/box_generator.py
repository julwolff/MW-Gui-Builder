# -*- coding: utf-8 -*-
"""
Modern GUI for ElecSim Box Generator
"""
from importlib.resources import files
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
from mw_gui_builder.core.generate_box import communicate_box_data, elongate_box, change_len_box

# CLASS

class Atom_ff:
    
    def __init__(self, list_line,name):
        
        list_line = list_line.split()
        self.name = name
        self.charge = list_line[2]
        try:
            self.sigma = list_line[4]
        except:
            self.sigma = 0.000
        try:
            self.epsilon = list_line[3]
        except:
            self.epsilon = 0.000
        
        
        with files("mw_gui_builder.data").joinpath("mass.txt").open("r") as mass_file:
            lines = mass_file.readlines()
            
            for i in range(len(lines)):
                lines[i] = lines[i].split()
                
        # Instancie the mass of each species
        
        # For each sites in each molecules

                
                
                name_for_mass = self.name
                
                # Retire les chiffres du nom de l'espece pour
                # determiner sa masse dans le tableau
                
                
                for i in name_for_mass:
                    if not i.isalpha():
                        name_for_mass = name_for_mass.replace(i, "")
                        
                for i in range(len(lines)):
                    if name_for_mass == lines[i][0]:
                        self.mass = lines[i][1]
                        
                    elif i == len(lines):
                        print(f"no mass found for {self.name}")
                        
    def print_ff(self):
        return (
            f"{self.name:<4}"        # type, left-aligned, width 4
            f"{self.name:<4}"        # repeat type
            f"{float(self.mass):>8.3f}"   # mass, right-aligned, 3 decimals
            f"{float(self.charge):>8.2f}" # charge, right-aligned, 2 decimals
            f"{'lj':>6}"             # potential keyword
            f"{float(self.sigma):>9.4f}"  # sigma, 4 decimals
            f"{float(self.epsilon):>9.5f}"# epsilon, 5 decimals
        )

class GuiBoxGenerator:
    """Modern ttk GUI for generating molecular boxes."""

    def __init__(self, master):
        self.master = master
        master.title("ElecSim – Box Generator")

        self.molecule_list = []
        self.number_list = []

        # Setup ttk style
        style = ttk.Style()
        style.theme_use("clam")

        # Create GUI sections
        self.create_input_section()
        self.create_display_section()
        self.create_mode_buttons()
        self.create_size_input()
        self.create_box_shape_buttons()
        self.create_launch_button()

        # Flags
        self.density_selected = False
        self.border_selected = False
        self.box_selected = False
        self.cube_selected = False
        self.quarter_selected = False

    def create_input_section(self):
        frame = ttk.LabelFrame(self.master, text="Add Molecule")
        frame.pack(padx=10, pady=5, fill='x')

        ttk.Label(frame, text="Name:").grid(row=0, column=0, padx=5, pady=5)
        self.molecule_entry = ttk.Entry(frame)
        self.molecule_entry.grid(row=0, column=1)

        ttk.Label(frame, text="Count:").grid(row=0, column=2, padx=5)
        self.number_entry = ttk.Entry(frame)
        self.number_entry.grid(row=0, column=3)

        ttk.Button(frame, text="Add", command=self.add_number).grid(row=0, column=4, padx=5)
        ttk.Button(frame, text="Remove Last", command=self.remove_item).grid(row=0, column=5, padx=5)

    def create_display_section(self):
        frame = ttk.LabelFrame(self.master, text="Molecule List")
        frame.pack(padx=10, pady=5, fill='both')

        self.molecule_display = tk.Text(frame, height=5, state='disabled', wrap='none')
        self.molecule_display.pack(fill='both', padx=5, pady=5)

    def create_mode_buttons(self):
        frame = ttk.LabelFrame(self.master, text="Input Mode")
        frame.pack(padx=10, pady=5, fill='x')

        self.indication_message = ttk.Label(frame, text="Choose input mode:")
        self.indication_message.pack(pady=2)

        button_frame = ttk.Frame(frame)
        button_frame.pack()

        ttk.Button(button_frame, text="Density", command=self.select_density).pack(side='left', padx=5)
        ttk.Button(button_frame, text="Box Size", command=self.select_border).pack(side='left', padx=5)

    def create_size_input(self):
        frame = ttk.Frame(self.master)
        frame.pack(padx=10, pady=5)

        ttk.Label(frame, text="Value (Density in mol/L or Dimensions in Å):").pack()
        self.size_entry = ttk.Entry(frame)
        self.size_entry.pack(fill='x', padx=5)

    def create_box_shape_buttons(self):
        frame = ttk.LabelFrame(self.master, text="Box Shape")
        frame.pack(padx=10, pady=5, fill='x')

        ttk.Button(frame, text="Double Z", command=self.select_box).pack(side='left', padx=5)
        ttk.Button(frame, text="Cube", command=self.select_cube).pack(side='left', padx=5)
        ttk.Button(frame, text="1:5 (Elongated Z)", command=self.select_quarter).pack(side='left', padx=5)

    def create_launch_button(self):
        self.launch_button = ttk.Button(self.master, text="Launch Generation", command=self.launch)
        self.launch_button.pack(pady=10)

    def add_number(self):
        mol = self.molecule_entry.get().strip()
        num = self.number_entry.get().strip()

        if not mol or not num:
            messagebox.showerror("Input Error", "Please provide both molecule name and quantity.")
            return
        try:
            int(num)
        except ValueError:
            messagebox.showerror("Input Error", "Quantity must be a number.")
            return

        self.molecule_list.append(mol)
        self.number_list.append(num)

        self.update_molecule_display()
        self.molecule_entry.delete(0, 'end')
        self.number_entry.delete(0, 'end')

    def remove_item(self):
        if not self.molecule_list:
            messagebox.showinfo("Info", "No molecules to remove.")
            return

        removed = self.molecule_list.pop()
        self.number_list.pop()
        self.update_molecule_display()
        messagebox.showinfo("Removed", f"Removed last entry: {removed}")

    def update_molecule_display(self):
        self.molecule_display.config(state='normal')
        self.molecule_display.delete("1.0", "end")
        for mol, num in zip(self.molecule_list, self.number_list):
            self.molecule_display.insert("end", f"{mol} : {num}\n")
        self.molecule_display.config(state='disabled')

    def select_density(self):
        self.density_selected = True
        self.border_selected = False
        self.indication_message.config(text="Enter density in mol/L")

    def select_border(self):
        self.border_selected = True
        self.density_selected = False
        self.indication_message.config(text="Enter box size in Å (e.g., 40x40x40)")

    def select_cube(self):
        self.cube_selected = True
        self.box_selected = False
        self.quarter_selected = False
        messagebox.showinfo("Shape", "Cube shape selected.")

    def select_box(self):
        self.box_selected = True
        self.cube_selected = False
        self.quarter_selected = False
        messagebox.showinfo("Shape", "Double Z box selected.")

    def select_quarter(self):
        self.quarter_selected = True
        self.box_selected = False
        self.cube_selected = False
        messagebox.showinfo("Shape", "1:5 Z elongation selected.")

    def launch(self):
        if not self.molecule_list:
            messagebox.showerror("Error", "No molecules added.")
            return

        if not (self.density_selected or self.border_selected):
            messagebox.showerror("Error", "Please select an input mode (density or box size).")
            return


        species = []

        # List all the species contained in _pack.xyz
        for mol in range(len(self.molecule_list)):
            file_pack = "molecules/" + self.molecule_list[mol].split('.')[0] + ".xyz"
            print(f"Processing file: {file_pack}")
            with open(file_pack, 'r') as rfile:
                lines = rfile.readlines()
                for i in range(2, len(lines)):
                    species.append(lines[i].split()[0])
                    print(f"Found species: {species[-1]}")

        # Distinguish different species
        for i in range(len(species)):
            j = 0
            while species[i] + str(j) in species != True:
                j += 1
            species[i] = species[i] + str(j)
                    
        
        # Rewrite each file
        i = 2
        for mol in range(len(self.molecule_list)):
            file_pack = "molecules/" + self.molecule_list[mol].split('.')[0] + ".xyz"
            file_dest = "generated/" + self.molecule_list[mol].split('.')[0] + "_ff.xyz"
            
            print(f"Rewriting file: {file_pack}")
    
            with open(file_pack, 'r') as rfile:
                lines = rfile.readlines()
                for j in range(2, len(lines)):
                    lines[j] = lines[j].replace(lines[j].split()[0], species[i - 2])
                    i += 1
                
                tmp_name = lines[1].split()
                tmp_name.append('generated/ff.ff\n')
                lines[1] = ' '.join(tmp_name)
                    
            # Rewrite in the files
            with open(file_dest, 'w') as wfile:
                for k in range(len(lines)):
                    wfile.write(lines[k])

        
        # Prepare ff_param and write tmp structures
        
        sto_ff = []
        
        for mol in range(len(self.molecule_list)):
            file_els = "molecules/" + self.molecule_list[mol].split('.')[0] + ".els"
            with open (file_els,'r') as rfile:
                lines = rfile.readlines()
                for i in range(len(lines)):
                        
                    if "PARAMETERS" in lines[i]:
                        break
                    
                    else:
                        sto_ff.append(lines[i])
                        
                
        
        # Create Atom_ff objects
        
        forcefield=[]
        
        for i in range(len(species)):
            
            at_ff = Atom_ff(sto_ff[i], species[i])
            forcefield.append(at_ff)
            
        with open("generated/ff.ff",'w') as wfile:
            
            lines = ["ATOMS\n","#   type   m/u     q/e    pot   pars\n"]
            
            for i in forcefield:
                lines.append((i.print_ff())+"\n")
            
            for k in range(len(lines)):
                wfile.write(lines[k])
            
        
            
                        
                
            
        self.molecule_ff_list = []
        
        for mol in self.molecule_list:
            
            name = mol.split('.')[0]
            
            idid = name + "_ff.xyz"
            
            self.molecule_ff_list.append(idid)
                                    
                    
        # Construct fftool command
        command = str(files("mw_gui_builder").joinpath("bin", "fftool"))
        for mol, num in zip(self.molecule_ff_list, self.number_list):
            command += f" {num} generated/{mol}"

        if self.density_selected:
            command += f" -r {self.size_entry.get()}"
        elif self.border_selected:
            command += f" -b {self.size_entry.get()}"
         
        try:
            messagebox.showinfo("Running", "Generating packmol file with fftool...")
            subprocess.call(command, shell=True)

            if self.box_selected:
                change_len_box()
            elif self.quarter_selected:
                elongate_box(5)
        
        except Exception as e:
            messagebox.showerror("Execution Error", f"An error occurred:\n{str(e)}")

        
        species = []

        # List all the species contained in _ff_pack.xyz
        for mol in range(len(self.molecule_ff_list)):
            file_pack = "molecules/" + self.molecule_list[mol].split('.')[0] + ".xyz"
            print(f"Processing file: {file_pack}")
            with open(file_pack, 'r') as rfile:
                lines = rfile.readlines()
                for i in range(2, len(lines)):
                    species.append(lines[i].split()[0])
                    print(f"Found species: {species[-1]}")

        # Distinguish different species
        for i in range(len(species)):
            j = 0
            while species[i] + str(j) in species != True:
                j += 1
            species[i] = species[i] + str(j)
                    
        # Rewrite each file
        i = 2
        for mol in range(len(self.molecule_ff_list)):
            file_pack = "molecules/" + self.molecule_list[mol].split('.')[0] + ".xyz"
            file_dest = "generated/" + self.molecule_ff_list[mol].split('.')[0] + "_pack.xyz"
            
            print(f"Rewriting file: {file_pack}")
    
            with open(file_pack, 'r') as rfile:
                lines = rfile.readlines()
                for j in range(2, len(lines)):
                    lines[j] = lines[j].replace(lines[j].split()[0], species[i - 2])
                    i += 1
                
                tmp_name = lines[1].split()
                tmp_name.append('generated/ff.ff\n')
                lines[1] = ' '.join(tmp_name)
                    
            # Rewrite in the files
            with open(file_dest, 'w') as wfile:
                for k in range(len(lines)):
                    wfile.write(lines[k])

            


        try:
            messagebox.showinfo("Packmol", "Launching packmol...")
            subprocess.call("packmol < pack.inp", shell=True)
            communicate_box_data()

            messagebox.showinfo("Success", "Box generation complete.")
        except Exception as e:
            messagebox.showerror("Execution Error", f"An error occurred:\n{str(e)}")

